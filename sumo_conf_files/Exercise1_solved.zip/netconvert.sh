#!/bin/bash

# Fixed SUMO network build script
# This script creates all necessary files and builds the network correctly

echo "Creating SUMO network files..."

# Create nodes.nod.xml
cat > nodes.nod.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<nodes version="1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/nodes_file.xsd">
    <!-- Intersection nodes -->
    <node id="J1" x="0.0" y="100.0" type="priority"/>
    <node id="J2" x="100.0" y="100.0" type="priority"/>
    <node id="J3" x="200.0" y="100.0" type="priority"/>
    <node id="J4" x="0.0" y="0.0" type="priority"/>
    <node id="J5" x="100.0" y="0.0" type="priority"/>
    <node id="J6" x="200.0" y="0.0" type="priority"/>
    
    <!-- External connection nodes -->
    <node id="N1" x="-50.0" y="100.0" type="priority"/>
    <node id="N2" x="250.0" y="100.0" type="priority"/>
    <node id="N3" x="-50.0" y="0.0" type="priority"/>
    <node id="N4" x="250.0" y="0.0" type="priority"/>
    <node id="N5" x="0.0" y="150.0" type="priority"/>
    <node id="N6" x="100.0" y="150.0" type="priority"/>
    <node id="N7" x="200.0" y="150.0" type="priority"/>
    <node id="N8" x="0.0" y="-50.0" type="priority"/>
    <node id="N9" x="100.0" y="-50.0" type="priority"/>
    <node id="N10" x="200.0" y="-50.0" type="priority"/>
</nodes>
EOF

# Create edges.edg.xml
cat > edges.edg.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<edges version="1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/edges_file.xsd">
    <!-- Horizontal edges (main grid) -->
    <edge id="E1_2" from="J1" to="J2" priority="2" numLanes="1" speed="13.89"/>
    <edge id="E2_3" from="J2" to="J3" priority="2" numLanes="1" speed="13.89"/>
    <edge id="E4_5" from="J4" to="J5" priority="2" numLanes="1" speed="13.89"/>
    <edge id="E5_6" from="J5" to="J6" priority="2" numLanes="1" speed="13.89"/>
    
    <!-- Vertical edges (main grid) -->
    <edge id="E1_4" from="J1" to="J4" priority="2" numLanes="1" speed="13.89"/>
    <edge id="E2_5" from="J2" to="J5" priority="2" numLanes="1" speed="13.89"/>
    <edge id="E3_6" from="J3" to="J6" priority="2" numLanes="1" speed="13.89"/>
    
    <!-- External connections -->
    <edge id="EN1_1" from="N1" to="J1" priority="1" numLanes="1" speed="13.89"/>
    <edge id="E3_N2" from="J3" to="N2" priority="1" numLanes="1" speed="13.89"/>
    <edge id="EN3_4" from="N3" to="J4" priority="1" numLanes="1" speed="13.89"/>
    <edge id="E6_N4" from="J6" to="N4" priority="1" numLanes="1" speed="13.89"/>
    <edge id="EN5_1" from="N5" to="J1" priority="1" numLanes="1" speed="13.89"/>
    <edge id="EN6_2" from="N6" to="J2" priority="1" numLanes="1" speed="13.89"/>
    <edge id="EN7_3" from="N7" to="J3" priority="1" numLanes="1" speed="13.89"/>
    <edge id="E4_N8" from="J4" to="N8" priority="1" numLanes="1" speed="13.89"/>
    <edge id="E5_N9" from="J5" to="N9" priority="1" numLanes="1" speed="13.89"/>
    <edge id="E6_N10" from="J6" to="N10" priority="1" numLanes="1" speed="13.89"/>
</edges>
EOF

# Create simplified connections.con.xml (fixed format)
cat > connections.con.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<connections version="1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/connections_file.xsd">
    <!-- Only allow straight-through movements at each junction -->
    
    <!-- Junction J1 -->
    <connection from="EN1_1" to="E1_2" fromLane="0" toLane="0"/>
    <connection from="EN5_1" to="E1_4" fromLane="0" toLane="0"/>
    
    <!-- Junction J2 -->
    <connection from="E1_2" to="E2_3" fromLane="0" toLane="0"/>
    <connection from="EN6_2" to="E2_5" fromLane="0" toLane="0"/>
    
    <!-- Junction J3 -->
    <connection from="E2_3" to="E3_N2" fromLane="0" toLane="0"/>
    <connection from="EN7_3" to="E3_6" fromLane="0" toLane="0"/>
    
    <!-- Junction J4 -->
    <connection from="EN3_4" to="E4_5" fromLane="0" toLane="0"/>
    <connection from="E1_4" to="E4_N8" fromLane="0" toLane="0"/>
    
    <!-- Junction J5 -->
    <connection from="E4_5" to="E5_6" fromLane="0" toLane="0"/>
    <connection from="E2_5" to="E5_N9" fromLane="0" toLane="0"/>
    
    <!-- Junction J6 -->
    <connection from="E5_6" to="E6_N4" fromLane="0" toLane="0"/>
    <connection from="E3_6" to="E6_N10" fromLane="0" toLane="0"/>
</connections>
EOF

# Create routes.rou.xml
cat > routes.rou.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<routes xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/routes_file.xsd">
    <vType id="car" accel="2.6" decel="4.5" sigma="0.5" length="5.0" maxSpeed="50.0"/>
    
    <!-- Routes for straight movements only -->
    <route id="horizontal_top" edges="EN1_1 E1_2 E2_3 E3_N2"/>
    <route id="horizontal_bottom" edges="EN3_4 E4_5 E5_6 E6_N4"/>
    <route id="vertical_left" edges="EN5_1 E1_4 E4_N8"/>
    <route id="vertical_middle" edges="EN6_2 E2_5 E5_N9"/>
    <route id="vertical_right" edges="EN7_3 E3_6 E6_N10"/>
    
    <!-- Traffic flows -->
    <flow id="flow_h_top" route="horizontal_top" begin="0" end="3600" vehsPerHour="300" type="car"/>
    <flow id="flow_h_bottom" route="horizontal_bottom" begin="0" end="3600" vehsPerHour="300" type="car"/>
    <flow id="flow_v_left" route="vertical_left" begin="0" end="3600" vehsPerHour="200" type="car"/>
    <flow id="flow_v_middle" route="vertical_middle" begin="0" end="3600" vehsPerHour="200" type="car"/>
    <flow id="flow_v_right" route="vertical_right" begin="0" end="3600" vehsPerHour="200" type="car"/>
</routes>
EOF

# Create configuration file
cat > network.sumocfg << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<configuration xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/sumoConfiguration.xsd">
    <input>
        <net-file value="network.net.xml"/>
        <route-files value="routes.rou.xml"/>
    </input>
    <time>
        <begin value="0"/>
        <end value="3600"/>
        <step-length value="0.1"/>
    </time>
    <processing>
        <collision.action value="warn"/>
        <collision.check-junctions value="true"/>
    </processing>
    <report>
        <verbose value="true"/>
        <no-step-log value="false"/>
    </report>
</configuration>
EOF

echo "All input files created successfully!"
echo ""

# Build the network
echo "Building SUMO network..."
netconvert \
    --node-files=nodes.nod.xml \
    --edge-files=edges.edg.xml \
    --connection-files=connections.con.xml \
    --output-file=network.net.xml \
    --no-turnarounds=true \
    --junctions.corner-detail=5 \
    --junctions.limit-turn-speed=5.50 \
    --verbose

# Check if network was created successfully
if [ -f "network.net.xml" ]; then
    echo ""
    echo "✅ Network generation successful!"
    echo ""
    echo "Files created:"
    echo "  📄 nodes.nod.xml"
    echo "  📄 edges.edg.xml" 
    echo "  📄 connections.con.xml"
    echo "  📄 routes.rou.xml"
    echo "  📄 network.sumocfg"
    echo "  🌐 network.net.xml"
    echo ""
    echo "To run simulation:"
    echo "  🚗 Command line: sumo -c network.sumocfg"
    echo "  🖥️  With GUI: sumo-gui -c network.sumocfg"
    echo ""
    echo "Network features:"
    echo "  ✓ No turning movements allowed"
    echo "  ✓ Only straight-through traffic"
    echo "  ✓ 6 intersections in 2x3 grid"
    echo "  ✓ External entry/exit points"
else
    echo ""
    echo "❌ Network generation failed!"
    echo "Please check SUMO installation and error messages above."
    echo ""
    echo "Common issues:"
    echo "  - SUMO not installed or not in PATH"
    echo "  - Input file format errors"
    echo "  - Missing dependencies"
fi